﻿#pragma once
#include<iostream>
using namespace std;
class Class_sp
{
private:
	int thuc;
	int ao;
public:
//khởi tạo hàm
	Class_sp();
	Class_sp(int thuc);
	Class_sp(int thuc, int ao);
	
// hàm nhập xuất
	friend ostream& operator << (ostream& o, Class_sp& p);
	friend istream& operator >>(istream& i, Class_sp& p);
//hàm tính 
//cong hai so phuc
	friend Class_sp& operator+(Class_sp p, Class_sp q);
	
	friend Class_sp& operator-(Class_sp p, Class_sp q);
	friend Class_sp& operator*(Class_sp p, Class_sp q);


};

