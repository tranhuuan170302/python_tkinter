// sophuc.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Class_sp.h"
using namespace std;

int main()
{
    Class_sp p;
    Class_sp q;
   // Class_sp p(3, 8);
    //Class_sp q(2, 5);
    Class_sp s(2);
    cout << "nhap vao so phuc p: ";
    cin >> p;
    cout << endl;

    cout << "nhap vao so phuc q: ";
    cin >> q;

    
    cout << "xuat ra mot so phuc:";
    cout << p;

    cout << endl << "xuat ra so phuc thu 2: ";
    cout << q;

    cout << endl<< "cong hai so phuc: ";
    Class_sp c = q + p;
    cout << c;
    cout << endl << "cong so phuc va so nguyen: ";
    Class_sp w = s + q;
    cout << w;
    
    cout << endl << "tru hai so phuc: ";
    Class_sp t = q - p;
    cout << t;
    cout << endl << "nhan hai so phuc: ";
    Class_sp n = q * p;
    cout << n;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
