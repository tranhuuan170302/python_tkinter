#include "Class_sp.h"

Class_sp::Class_sp()
{
	this->thuc = thuc;
	this->ao = ao;
}

Class_sp::Class_sp(int thuc)
{
	this->thuc=thuc;
	this->ao = 0;
}

Class_sp::Class_sp(int thuc, int ao)
{
	this->thuc = thuc;
	this->ao = ao;
}

ostream& operator<<(ostream& o, Class_sp& p)
{
	return o << p.thuc<<"+"<<p.ao<<"i";
	// TODO: insert return statement here
}

istream& operator>>(istream& i, Class_sp& p)
{
	return i >> p.thuc >> p.ao;
	// TODO: insert return statement here
}

Class_sp& operator+(Class_sp p, Class_sp q)
{
	return *(new  Class_sp(p.thuc+q.thuc,p.ao+q.ao));
	// TODO: insert return statement here
}


Class_sp& operator-(Class_sp p, Class_sp q)
{
	return *(new Class_sp(p.thuc - q.thuc, p.ao - q.ao));
	// TODO: insert return statement here
}

Class_sp& operator*(Class_sp p, Class_sp q)
{
	return *(new Class_sp(p.thuc * q.thuc - p.ao * q.ao, p.thuc * q.ao + q.thuc * p.ao));
	// TODO: insert return statement here
}


